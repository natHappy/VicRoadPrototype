﻿using System;
using System.Collections.Generic;
using System.Text;

namespace NewPOM.Bases
{
    public abstract class BasePage : Base
    {
        public BasePage(ParallelConfig parellelConfig) : base(parellelConfig)
        {
        }
    }
}
