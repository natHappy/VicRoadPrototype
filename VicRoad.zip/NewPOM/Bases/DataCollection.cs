﻿using System;
using System.Collections.Generic;
using System.Text;

namespace NewPOM.Bases
{ 
    public class Datacollection
    {
        public int rowNumber { get; set; }
        public string colName { get; set; }
        public string colValue { get; set; }
    }
}
