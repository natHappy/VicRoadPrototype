﻿using System;
using System.Collections.Generic;
using System.Text;

namespace NewPOM.Bases
{
    public class BaseStep : Base
    {
        public BaseStep(ParallelConfig parellelConfig) : base(parellelConfig)
        {
        }
    }
}
